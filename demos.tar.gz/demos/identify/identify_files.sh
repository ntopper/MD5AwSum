echo '*************************************************'
echo ''
echo ''
echo 'This demo will attempt to identify 3 mystery files using a remote hash table repository'
echo ''
echo ''

echo 'Adding http://md5awsumdev.appspot.com/testrepo'
echo | ./MD5AwSum -a http://md5awsumdev.appspot.com/testrepo

echo ''
echo ''

echo 'identifying mystery1.dat:'
echo | ./MD5AwSum demos/identify/mystery1.dat

echo ''
echo ''

echo 'identifying mystery2.dat:'
echo | ./MD5AwSum demos/identify/mystery2.dat

echo ''
echo ''

echo 'identifying mystery3.dat:'
echo | ./MD5AwSum demos/identify/mystery3.dat
