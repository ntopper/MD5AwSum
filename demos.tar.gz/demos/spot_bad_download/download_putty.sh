echo '*************************************************'
echo ''
echo ''
echo 'This demo will download a good version of putty.exe, and then a tampered verson'
echo 'The tampered version will be identified and deleted'
echo ''
echo ''

echo 'Trying https://dl.dropboxusercontent.com/u/4589147/evil_putty'
if ! ./MD5AwSum -d https://dl.dropboxusercontent.com/u/4589147/evil_putty/putty.exe | grep 'name: Putty.exe' ;then
   echo 'Bad Putty Found!'
   echo 'Removing Bad Putty'
   rm putty.exe
else
	echo 'Good Putty Found!'
fi

echo ''
echo ''

echo 'Trying https://dl.dropboxusercontent.com/u/4589147/real_putty'
if ! ./MD5AwSum -d https://dl.dropboxusercontent.com/u/4589147/real_putty/putty.exe | grep 'name: Putty.exe' ;then
   echo 'Bad Putty Found!'
   echo 'Removing Bad Putty'
   rm putty.exe
else
	echo 'Good Putty Found!'
	mv putty.exe demos/spot_bad_download
fi
