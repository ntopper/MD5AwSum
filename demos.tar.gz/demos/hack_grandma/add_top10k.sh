#!/bin/sh
#Adds the top 100k passowrds from 10k.tx

mkdir top10k
cat demos/hack_grandma/10k.txt | while read passwrd
do #make a file called password contaning the password
   touch top10k/$passwrd
   printf $passwrd > top10k/$passwrd
done

#add all the generated files
./MD5AwSum -g top10k

#delete evedence
rm -r top10k
