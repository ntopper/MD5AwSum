#Adds the top 100k passowrds from 10k.tx

mkdir top10k
cat demos/hack_grandma/10k.txt | while read passwrd
do #remove each hash from the table identified by the name
   ./md5awsum -r $passwrd

done
